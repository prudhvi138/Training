package com.cts.training.companyservice;

public class CompanyController {

}
