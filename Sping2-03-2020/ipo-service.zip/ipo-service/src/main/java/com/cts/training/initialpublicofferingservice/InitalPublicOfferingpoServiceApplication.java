package com.cts.training.initialpublicofferingservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InitalPublicOfferingpoServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(InitalPublicOfferingpoServiceApplication.class, args);
	}

}
