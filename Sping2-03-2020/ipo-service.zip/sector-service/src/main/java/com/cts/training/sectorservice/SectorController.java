package com.cts.training.sectorservice;

public class SectorController {

}
