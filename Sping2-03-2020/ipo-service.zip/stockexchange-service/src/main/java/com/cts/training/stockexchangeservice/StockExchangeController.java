package com.cts.training.stockexchangeservice;

public class StockExchangeController {

}
