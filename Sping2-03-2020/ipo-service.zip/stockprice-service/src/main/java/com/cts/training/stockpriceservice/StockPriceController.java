package com.cts.training.stockpriceservice;

public class StockPriceController {

}
